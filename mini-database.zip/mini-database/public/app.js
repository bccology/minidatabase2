const $ = (id) => document.getElementById(id);
const modal = $("modal"), form = $("form"), errorEl = $("error");

async function load() {
  const res = await fetch("/api/profiles");
  const rows = await res.json();
  $("count").textContent = `${rows.length} profile${rows.length === 1 ? "" : "s"}`;
  $("empty").hidden = rows.length > 0;
  const list = $("list");
  list.innerHTML = "";
  for (const r of rows) {
    const el = document.createElement("div");
    el.className = "profile";
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = r.name.charAt(0).toUpperCase();
    const info = document.createElement("div");
    info.className = "info";
    const n = document.createElement("strong");
    n.textContent = r.name;
    const a = document.createElement("span");
    a.textContent = `Age: ${r.age}`;
    info.append(n, a);
    const del = document.createElement("button");
    del.className = "del";
    del.title = "Delete";
    del.textContent = "✕";
    del.onclick = async () => {
      if (!confirm(`Delete ${r.name}?`)) return;
      await fetch(`/api/profiles/${r.id}`, { method: "DELETE" });
      load();
    };
    el.append(avatar, info, del);
    list.append(el);
  }
}

function openModal() {
  form.reset();
  errorEl.hidden = true;
  modal.hidden = false;
  $("name").focus();
}
const closeModal = () => (modal.hidden = true);

$("addBtn").onclick = openModal;
$("cancel").onclick = closeModal;
modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const res = await fetch("/api/profiles", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: $("name").value, age: $("age").value }),
  });
  if (!res.ok) {
    errorEl.textContent = (await res.json()).error || "Something went wrong.";
    errorEl.hidden = false;
    return;
  }
  closeModal();
  load();
});

load();
